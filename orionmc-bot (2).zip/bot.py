import os
import json
import logging
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

# === CONFIG ===
TELEGRAM_BOT_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN', '')
DATA_FILE = "data.json"
PORT = int(os.environ.get('PORT', 8080))

RANK_HIERARCHY = ["Owner", "Sr.Admin", "Admin", "Sr.Mod", "Mod", "Helper"]
ADMIN_RANKS = ["Owner", "Admin"]

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# === WEB SERVER (per Railway) ===
class HealthHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b'Bot OrionMC attivo!')
    def log_message(self, format, *args):
        pass

def run_health_server():
    server = HTTPServer(('0.0.0.0', PORT), HealthHandler)
    logger.info(f"Health server su porta {PORT}")
    server.serve_forever()

# === JSON DATABASE ===
def load_data():
    try:
        with open(DATA_FILE, 'r') as f:
            return json.load(f)
    except:
        return {"registered_users": [], "stafflist": []}

def save_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=2)

def find_user(data, telegram_id, chat_id):
    for u in data["registered_users"]:
        if u["telegram_id"] == telegram_id and u["chat_id"] == chat_id:
            return u
    return None

def find_staff(data, ign=None, telegram_id=None, chat_id=None):
    for s in data["stafflist"]:
        if chat_id and s["chat_id"] != chat_id:
            continue
        if ign and s["ign"] == ign:
            return s
        if telegram_id and s["telegram_id"] == telegram_id:
            return s
    return None

def get_user_rank(telegram_id, chat_id):
    data = load_data()
    staff = find_staff(data, telegram_id=telegram_id, chat_id=chat_id)
    return staff["rank"] if staff else None

def is_admin(telegram_id, chat_id):
    return get_user_rank(telegram_id, chat_id) in ADMIN_RANKS

# === COMMANDS ===
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "⚜️ Benvenuto nel Bot Staff di OrionMC! ⚜️\n\n"
        "/register <IGN> - Registrati\n"
        "/setowner - Diventa Owner\n"
        "/stafflist - Lista staff\n"
        "/help - Tutti i comandi"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "⚜️ <b>Comandi Bot OrionMC</b> ⚜️\n\n"
        "<b>Utente:</b>\n"
        "/register &lt;IGN&gt; - Registrati\n"
        "/setowner - Diventa Owner\n"
        "/stafflist - Lista staff\n\n"
        "<b>Admin:</b>\n"
        "/pex &lt;nick&gt; &lt;rank&gt; - Promuovi\n"
        "/depex &lt;nick&gt; - Rimuovi + ban\n"
        "/degrade &lt;nick&gt; &lt;rank&gt; - Cambia grado\n"
        "/remove &lt;nick&gt; - Rimuovi da staff\n\n"
        "<b>Owner:</b>\n"
        "/removeowner &lt;nick&gt; - Rimuovi Owner",
        parse_mode='HTML'
    )

async def register_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("❌ Usa: /register <IGN>")
        return
    
    ign = " ".join(context.args)
    telegram_id = update.effective_user.id
    telegram_username = update.effective_user.username or update.effective_user.first_name
    chat_id = update.effective_chat.id
    
    data = load_data()
    
    if find_user(data, telegram_id, chat_id):
        await update.message.reply_text("⚠️ Sei già registrato!")
        return
    
    data["registered_users"].append({
        "telegram_id": telegram_id,
        "telegram_username": telegram_username,
        "ign": ign,
        "chat_id": chat_id
    })
    save_data(data)
    await update.message.reply_text(f"✅ Registrazione completata! IGN: {ign}")

async def setowner_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    telegram_id = update.effective_user.id
    telegram_username = update.effective_user.username or update.effective_user.first_name
    chat_id = update.effective_chat.id
    
    data = load_data()
    
    for s in data["stafflist"]:
        if s["chat_id"] == chat_id and s["rank"] == "Owner":
            await update.message.reply_text("❌ Esiste già un Owner!")
            return
    
    user = find_user(data, telegram_id, chat_id)
    if not user:
        await update.message.reply_text("❌ Registrati prima con /register <IGN>")
        return
    
    data["stafflist"].append({
        "telegram_id": telegram_id,
        "telegram_username": telegram_username,
        "ign": user["ign"],
        "rank": "Owner",
        "chat_id": chat_id
    })
    save_data(data)
    await update.message.reply_text(f"⚜️ {user['ign']} è ora Owner! ⚜️✅")

async def pex_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    telegram_id = update.effective_user.id
    chat_id = update.effective_chat.id
    
    if not is_admin(telegram_id, chat_id):
        await update.message.reply_text("❌ Non hai i permessi.")
        return
    
    if len(context.args) < 2:
        await update.message.reply_text("❌ Usa: /pex <nick> <rank>")
        return
    
    nick, rank = context.args[0], context.args[1]
    if rank not in RANK_HIERARCHY:
        await update.message.reply_text(f"❌ Rank non valido: {', '.join(RANK_HIERARCHY)}")
        return
    
    data = load_data()
    admin_user = find_user(data, telegram_id, chat_id)
    admin_nick = admin_user["ign"] if admin_user else update.effective_user.username
    
    target = None
    for u in data["registered_users"]:
        if u["ign"] == nick and u["chat_id"] == chat_id:
            target = u
            break
    
    if not target:
        await update.message.reply_text(f"❌ '{nick}' non trovato.")
        return
    
    existing = find_staff(data, ign=nick, chat_id=chat_id)
    if existing:
        existing["rank"] = rank
    else:
        data["stafflist"].append({
            "telegram_id": target["telegram_id"],
            "telegram_username": target["telegram_username"],
            "ign": nick,
            "rank": rank,
            "chat_id": chat_id
        })
    
    save_data(data)
    await update.message.reply_text(f"⚜️ {admin_nick} ha pexato {nick} al grado di {rank}⚜️✅")

async def depex_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    telegram_id = update.effective_user.id
    chat_id = update.effective_chat.id
    
    if not is_admin(telegram_id, chat_id):
        await update.message.reply_text("❌ Non hai i permessi.")
        return
    
    if not context.args:
        await update.message.reply_text("❌ Usa: /depex <nick>")
        return
    
    nick = context.args[0]
    data = load_data()
    admin_user = find_user(data, telegram_id, chat_id)
    admin_nick = admin_user["ign"] if admin_user else update.effective_user.username
    
    staff = find_staff(data, ign=nick, chat_id=chat_id)
    if not staff:
        await update.message.reply_text(f"❌ '{nick}' non è nella stafflist.")
        return
    
    target_id = staff["telegram_id"]
    data["stafflist"].remove(staff)
    save_data(data)
    
    try:
        await context.bot.ban_chat_member(chat_id=chat_id, user_id=target_id)
    except:
        pass
    
    await update.message.reply_text(f"⚜️❌ {nick} è uscito dal gruppo a causa del depex da parte di {admin_nick}⚜️❌")

async def degrade_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    telegram_id = update.effective_user.id
    chat_id = update.effective_chat.id
    
    if not is_admin(telegram_id, chat_id):
        await update.message.reply_text("❌ Non hai i permessi.")
        return
    
    if len(context.args) < 2:
        await update.message.reply_text("❌ Usa: /degrade <nick> <nuovo_rank>")
        return
    
    nick, new_rank = context.args[0], context.args[1]
    if new_rank not in RANK_HIERARCHY:
        await update.message.reply_text(f"❌ Rank non valido.")
        return
    
    data = load_data()
    admin_user = find_user(data, telegram_id, chat_id)
    admin_nick = admin_user["ign"] if admin_user else update.effective_user.username
    
    staff = find_staff(data, ign=nick, chat_id=chat_id)
    if not staff:
        await update.message.reply_text(f"❌ '{nick}' non è nella stafflist.")
        return
    
    old_rank = staff["rank"]
    staff["rank"] = new_rank
    save_data(data)
    
    await update.message.reply_text(f"⚜️ {admin_nick} ha rimosso {nick} dal grado di {old_rank} e l'ha promosso al grado di {new_rank}⚜️")

async def remove_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    telegram_id = update.effective_user.id
    chat_id = update.effective_chat.id
    
    if not is_admin(telegram_id, chat_id):
        await update.message.reply_text("❌ Non hai i permessi.")
        return
    
    if not context.args:
        await update.message.reply_text("❌ Usa: /remove <nick>")
        return
    
    nick = context.args[0]
    data = load_data()
    admin_user = find_user(data, telegram_id, chat_id)
    admin_nick = admin_user["ign"] if admin_user else update.effective_user.username
    
    staff = find_staff(data, ign=nick, chat_id=chat_id)
    if not staff:
        await update.message.reply_text("❌ Utente non nella stafflist.")
        return
    
    old_rank = staff["rank"]
    data["stafflist"].remove(staff)
    save_data(data)
    
    await update.message.reply_text(f"⚜️ {admin_nick} ha rimosso {nick} dal grado di {old_rank} ⚜️❌")

async def removeowner_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    telegram_id = update.effective_user.id
    chat_id = update.effective_chat.id
    
    if get_user_rank(telegram_id, chat_id) != "Owner":
        await update.message.reply_text("❌ Solo Owner può usare questo comando.")
        return
    
    if not context.args:
        await update.message.reply_text("❌ Usa: /removeowner <nick>")
        return
    
    nick = context.args[0]
    data = load_data()
    
    staff = find_staff(data, ign=nick, chat_id=chat_id)
    if not staff or staff["rank"] != "Owner":
        await update.message.reply_text("❌ Utente non è Owner.")
        return
    
    if staff["telegram_id"] == telegram_id:
        await update.message.reply_text("❌ Non puoi rimuovere te stesso!")
        return
    
    admin_user = find_user(data, telegram_id, chat_id)
    admin_nick = admin_user["ign"] if admin_user else update.effective_user.username
    
    data["stafflist"].remove(staff)
    save_data(data)
    
    await update.message.reply_text(f"👑 {admin_nick} ha rimosso {nick} dal grado di Owner ⚜️❌")

async def stafflist_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    data = load_data()
    
    staff_members = [s for s in data["stafflist"] if s["chat_id"] == chat_id]
    
    if not staff_members:
        await update.message.reply_text("⚜️ <b>StaffList di OrionMC</b> ⚜️\n\n📭 <b>Vuota</b>", parse_mode='HTML')
        return
    
    staff_members.sort(key=lambda x: RANK_HIERARCHY.index(x["rank"]) if x["rank"] in RANK_HIERARCHY else 99)
    
    rank_emojis = {"Owner": "👑", "Sr.Admin": "⚔️", "Admin": "🛡️", "Sr.Mod": "⭐", "Mod": "🔰", "Helper": "💚"}
    
    message = "⚜️ <b>StaffList di OrionMC</b> ⚜️\n<b>━━━━━━━━━━━━━━━━━━━━</b>\n\n"
    current_rank = None
    for m in staff_members:
        rank, ign = m["rank"], m["ign"]
        if rank != current_rank:
            if current_rank: message += "\n"
            current_rank = rank
            message += f"{rank_emojis.get(rank, '📌')} <b>{rank}</b>\n"
        message += f"    ┗ <b>{ign}</b>\n"
    
    message += f"\n<b>━━━━━━━━━━━━━━━━━━━━</b>\n📊 <b>Totale:</b> {len(staff_members)}"
    await update.message.reply_text(message, parse_mode='HTML')

async def welcome_new_member(update: Update, context: ContextTypes.DEFAULT_TYPE):
    for member in update.message.new_chat_members:
        if member.is_bot: continue
        username = member.username or member.first_name
        await update.message.reply_text(
            f"Ciao {username}! 👋\n\nRegistrati con /register e il tuo IGN.⚜️\n\nBuona permanenza!✅"
        )

def main():
    # Avvia web server per Railway
    threading.Thread(target=run_health_server, daemon=True).start()
    
    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
    
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("register", register_command))
    app.add_handler(CommandHandler("setowner", setowner_command))
    app.add_handler(CommandHandler("pex", pex_command))
    app.add_handler(CommandHandler("depex", depex_command))
    app.add_handler(CommandHandler("degrade", degrade_command))
    app.add_handler(CommandHandler("remove", remove_command))
    app.add_handler(CommandHandler("removeowner", removeowner_command))
    app.add_handler(CommandHandler("stafflist", stafflist_command))
    app.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, welcome_new_member))
    
    logger.info("🚀 Bot avviato!")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
